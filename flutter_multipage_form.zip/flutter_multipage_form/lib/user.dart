class User {
  String fullName;
  String email;

  User({this.fullName = '', this.email = ''});
}
